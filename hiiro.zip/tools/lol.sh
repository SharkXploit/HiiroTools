#!/bin/bash                                                           
clear
figlet LocalHost
echo "SharkXploiter Crew"
echo "╭─Masukkan Port yang akan di gunakan di localhost example 8080"
read -p "╰─>" port
echo "╭─Masukkan File yang akan di jalankan di localhost"
read -p "╰─>" file
echo
echo
echo "Salin Dan Buka Di Browser : http://127.0.0.1":$port
echo
php -S 127.0.0.1:$port -t /sdcard/$file

