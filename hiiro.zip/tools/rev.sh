clear
figlet Tools Reverse IP
echo "Coded by '/Mine7 - SharkXploiter Crew"
echo
echo    "╭─Masukan Url Target [ Jangan Pake https/http ]"
read -p "╰─>" web
echo
curl https://api.hackertarget.com/reverseiplookup/?q=$web
echo
echo
read -p "kembali? y/t : " kampang

if [ $kampang = "y" ] || [ $kampang = "Y" ]
then
sh reverse.sh
fi

if [ $kampang = "t" ] || [ $kampang = "T" ]
then
exit
fi