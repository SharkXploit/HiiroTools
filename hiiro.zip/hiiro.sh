#!/bin/bash
clear

figlet Hiiro Tools
echo "Coded By '/Mine7 | SharkXploiter Crew"
echo
echo "1 Reverseip"
echo "2 LocalHost"
echo "3 Whois"
echo "4 Script Deface Creator"
echo "5 Webdav Auto Deface"
echo ""
read -p "Pilih Nomor : " oh

if [ $oh = 1 ] || [ $oh = 1 ]
then
cd $HOME/hiiro/tools/
sh rev.sh
fi

if [ $oh = 2 ] || [ $oh = 2 ]
then
cd $HOME/hiiro/tools/
sh lol.sh
fi

if [ $oh = 4 ] || [ $oh = 4 ]
then
cd $HOME/hiiro/tools/
python2 sc.py
fi

